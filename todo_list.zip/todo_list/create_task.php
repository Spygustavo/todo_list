<?php
include("config.php");

$data = json_decode(file_get_contents("php://input"));

$title = $conn->real_escape_string($data->title);
$description = $conn->real_escape_string($data->description);

$sql = "INSERT INTO tasks (title, description) VALUES ('$title', '$description')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(array("message" => "Tarefa criada com sucesso"));
} else {
    echo json_encode(array("error" => $conn->error));
}

$conn->close();
?>
