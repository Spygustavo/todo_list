<?php
include("config.php");

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;

$sql = "DELETE FROM tasks WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(array("message" => "Tarefa excluída com sucesso"));
} else {
    echo json_encode(array("error" => $conn->error));
}

$conn->close();
?>
