<?php
include("config.php");

$data = json_decode(file_get_contents("php://input"));

$sql = "SELECT id, title, description FROM tasks ORDER BY created_at DESC";
$res = $conn->query($sql);

$tasks = [];
if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $tasks[] = $row;
    }
}

echo json_encode($tasks);

$conn->close();
?>
