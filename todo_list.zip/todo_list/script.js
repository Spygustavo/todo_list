$(document).ready(function() {
    listarTasks();

    $('#taskForm').submit(function(event) {
        event.preventDefault();
        var id = $('#taskId').val();
        var title = $('#taskTitle').val();
        var description = $('#taskDescription').val();

        if (id) {
            editar(id, title, description);
        } else {
            criarTask(title, description);
        }
    });
});

function listarTasks() {
    $.ajax({
        url: 'get_tasks.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            mostrarTasks(response);
        },
        error: function(xhr, status, error) {
            console.error('Erro ao carregar tarefas:', error);
        }
    });
}

function mostrarTasks(tasks) {
    var tasksList = $('#tasks-list');
    tasksList.empty();

    $.each(tasks, function(index, task) {
        var taskItem = `
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">${task.title}</h5>
                    <p class="card-text">${task.description}</p>
                    <button type="button" class="btn btn-primary mr-2" onclick="formEditar(${task.id})">Editar</button>
                    <button type="button" class="btn btn-danger" onclick="deletaTask(${task.id})">Excluir</button>
                </div>
            </div>
        `;
        tasksList.append(taskItem);
    });
}

function criarTask(title, description) {
    $.ajax({
        url: 'create_task.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ title: title, description: description }),
        dataType: 'json',
        success: function(response) {
            $('#taskModal').modal('hide');
            listarTasks();
        },
        error: function(xhr, status, error) {
            console.error('Erro ao criar tarefa:', error);
        }
    });
}

function deletaTask(id) {
    if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
        $.ajax({
            url: 'delete_task.php',
            type: 'DELETE',
            contentType: 'application/json',
            data: JSON.stringify({ id: id }),
            dataType: 'json',
            success: function(response) {
                listarTasks();
            },
            error: function(xhr, status, error) {
                console.error('Erro ao excluir tarefa:', error);
            }
        });
    }
}

function formAdicionar(id = null) {
    if (id) {
        $.ajax({
            url: `get_tasks.php?id=${id}`,
            type: 'GET',
            dataType: 'json',
            success: function(task) {
                $('#editTaskModal #taskId').val(task.id);
                $('#editTaskModal #taskTitle').val(task.title);
                $('#editTaskModal #taskDescription').val(task.description);
                $('#editTaskModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error('Erro ao obter detalhes da tarefa:', error);
            }
        });
    } else {
        $('#addTaskModal #taskForm')[0].reset();
        $('#addTaskModal #taskId').val('');
        $('#addTaskModal').modal('show');
    }
}


function formEditar(id) {
    $.ajax({
        url: `get_tasks.php?id=${id}`,
        type: 'GET',
        dataType: 'json',
        success: function(task) {
            $('#editTaskId').val(task.id);
            $('#editTaskTitle').val(task.title);
            $('#editTaskDescription').val(task.description);
            $('#editTaskForm').off('submit');
            $('#editTaskModal').modal('show');

            $('#btnSalvarAlteracoes').click(function() {
                var id = $('#editTaskId').val();
                var title = $('#editTaskTitle').val();
                var description = $('#editTaskDescription').val();
                editar(id, title, description);
            });
        },
        error: function(xhr, status, error) {
            console.error('Erro ao obter detalhes da tarefa:', error);
        }
    });
}


function editar(id, title, description) {
    $.ajax({
        url: `update_task.php?id=${id}`,
        type: 'PUT',
        contentType: 'application/json',
        data: JSON.stringify({ id: id, title: title, description: description }),
        dataType: 'json',
        success: function(response) {
            $('#editTaskModal').modal('hide');
            listarTasks(); 
        },
        error: function(xhr, status, error) {
            console.error('Erro ao atualizar tarefa:', error);
        }
    });
}



