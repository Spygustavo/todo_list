<?php
include("config.php");

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;
$title = $conn->real_escape_string($data->title);
$description = $conn->real_escape_string($data->description);

$sql = "UPDATE tasks SET title = '$title', description = '$description' WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo ("message" => "Tarefa atualizada com sucesso");
} else {
    echo json_encode(array("error" => "Erro ao atualizar tarefa: " . $conn->error));
}

$conn->close();
?>
